package com.activities.am1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class CreateQuizResultActivity extends Activity {
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_quiz_result); 
        
	}

}
